// função 1

function validarcampos(){
    let data = document.getElementById("day").value;
    let mes = document.getElementById("month").value;
    let ano = document.getElementById("year").value;
    let cpf = document.getElementById("cpf").value;
    let cpfvalido = /^(( [ 0-9] {3}.[0-9]{3}.[0-9]{3}-[0-9]{2}))$/;
    let atual = new Data ();

    if((data >=1 && data <=31) &&(mes >=1 && mes <=12) &&(ano >=1900 && ano <=atual)){

    }
     else{
         window.location.href = "autoriza.html";
         alert("Sua data de nascimento foi recusada verifique o campo");

     }

     if (cpfvalido.test(cpf)== false){
         cpf = cpf.replace(/\D/g, " ");
         if (cpf.length == 11) { // TRANSFORMANDO PARA O PADRÃO
        cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2"); //coloca um ponto entre o terceiro e o quarto dígitos
        cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2"); //coloca um ponto entre o terceiro e o quarto dígitos
        let valorValido = document.getElementById("cpf").value = cpf;
     }
else{

    window.location.href = "autoriza.html";
    alert("reveja seu CPF Inválido");
  }     

}
// função 2

var verify_form = () => {

    if (validarcampos() == false) {
        alert("Dados incompletos");
        return

    }

    var obj_form = {
        
        name: "",

        nickname: "",

        birth_date: "",

        team_id: "",

        sport: []

    }

    var campo_nome = document.getElementById("name");
    if (campo_name.value == "")
    return null;
 obj_form.name = campo_name.value;
 var campo_apelide = document.getElementById("nickname");
 obj_form.nickname = campo_apelide.value;
 
 var campo_dia = document.getElementById("day");
 var campo_dia = document.getElementById("month");
 var campo_dia = document.getElementById("year");

 obj_form.birth_date = campo_ano.value + "/" + campo_dia.value;


   var campo_disp_1 = document.getElementById("sport_1").checked;
   if (campo_disp_1)
     obj_form.sport.push12);

     var campo_disp_1 = document.getElementById("sport_2").checked;
     if (campo_disp_2)
       obj_form.sport.push(2);

       var campo_disp_1 = document.getElementById("sport_3").checked;
       if (campo_disp_3)
         obj_form.sport.push(3);

         var campo_disp_1 = document.getElementById("sport_4").checked;
         if (campo_disp_4)
           obj_form.sport.push(4);

           var campo_disp_1 = document.getElementById("sport_5").checked;
           if (campo_disp_5)
             obj_form.sport.push(5);

             var campo_disp_1 = document.getElementById("sport_6").checked;
             if (campo_disp_6)
               obj_form.sport.push(6);

               var campo_disp_1 = document.getElementById("sport_7").checked;
               if (campo_disp_7)
                 obj_form.sport.push(7);